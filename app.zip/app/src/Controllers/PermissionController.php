<?php
namespace Controllers;

use Database\Connection;
use Models\Categoria;
use Security\Permission;
use Security\AlmoxPermission;

class PermissionController {

    /**
     * Visão geral de todas as permissões:
     * mostra, para cada código de permissão, quais usuários têm nível 1 ou 2.
     * Requer users.manage >= 1 (leitura).
     */
    public function overview() {
        \Security\Auth::requireAuth();
        \Security\Permission::require('users.manage', 2);

        $pdo = \Database\Connection::get();

        $codes = [
            'is_admin'                   => 'Administrador Global',
            'users.manage'               => 'Gestão de Usuários',
            'drilling.analise_di'        => 'Mining — Análise DI',
            'drilling.tabela_getman'     => 'Mining — Tabela Getman',
            'drilling.tabela_boart'      => 'Mining — Tabela Boart LongYear',
            'agro.tabela_massey'         => 'Agro — Tabela Massey Ferguson',
            'hr.colaboradores'           => 'Colaboradores',
            'hr.organograma_proposta'    => 'Organograma — Proposta',
            'rh.composicao_remuneracao'  => 'RH — Composição Remuneração',
            'almoxarifado.manage'        => 'Almoxarifado — Gerenciar configurações',
        ];

        // Busca todos os usuários com algum nível de acesso (> 0)
        $in = implode(',', array_fill(0, count($codes), '?'));
        $stmt = $pdo->prepare("
            SELECT up.permission_code, up.level, u.id, u.nome, u.login, u.origem
            FROM user_permissions up
            JOIN users u ON u.id = up.user_id
            WHERE up.level > 0 AND up.permission_code IN ($in)
            ORDER BY up.permission_code, up.level DESC, u.nome
        ");
        $stmt->execute(array_keys($codes));
        $rows = $stmt->fetchAll();

        // Agrupa: $byPerm[code][level] = [ {id, nome, login, origem}, … ]
        $byPerm = [];
        foreach (array_keys($codes) as $code) {
            $byPerm[$code] = [2 => [], 1 => []];
        }
        foreach ($rows as $row) {
            $lvl = (int)$row['level'];
            if (isset($byPerm[$row['permission_code']][$lvl])) {
                $byPerm[$row['permission_code']][$lvl][] = $row;
            }
        }

        // Seção Almoxarifado: permissões por categoria (níveis 1-3)
        $categorias = Categoria::findAll([], 'nome');
        $almoxCatCodes = array_map(fn($c) => 'almoxarifado.cat.' . $c->id, $categorias);
        $almoxByPerm = [];
        if (!empty($almoxCatCodes)) {
            $inAlm = implode(',', array_fill(0, count($almoxCatCodes), '?'));
            $stAlm = $pdo->prepare("
                SELECT up.permission_code, up.level, u.id, u.nome, u.login, u.origem
                FROM dbo.user_permissions up
                JOIN dbo.users u ON u.id = up.user_id
                WHERE up.level > 0 AND up.permission_code IN ($inAlm)
                ORDER BY up.permission_code, up.level DESC, u.nome
            ");
            $stAlm->execute($almoxCatCodes);
            foreach ($categorias as $cat) {
                $almoxByPerm[$cat->id] = ['nome' => $cat->nome, 3 => [], 2 => [], 1 => []];
            }
            foreach ($stAlm->fetchAll() as $row) {
                $parts = explode('.', $row['permission_code']);
                $catId = (int)end($parts);
                $lvl   = (int)$row['level'];
                if (isset($almoxByPerm[$catId][$lvl])) {
                    $almoxByPerm[$catId][$lvl][] = $row;
                }
            }
        }

        render_page('permissions/overview.php', [
            'codes'       => $codes,
            'byPerm'      => $byPerm,
            'categorias'  => $categorias,
            'almoxByPerm' => $almoxByPerm,
        ]);
    }

    /**
     * Exibe/edita a permissão 'users.manage' (0/1/2) para um usuário-alvo (local ou AD).
     * Necessita do chamador ter nível 2 (escrita) em 'users.manage'.
     * GET  ?id=  -> formulário (parcial em modal com ?modal=1)
     * POST ?id=  -> salva (se ?ajax=1, retorna JSON)
     */
   public function edit() {
		\Security\Auth::requireAuth();
		\Security\Permission::require('users.manage', 2); // quem gerencia permissões precisa escrita em Usuários

		$pdo = \Database\Connection::get();
		$targetId = (int)($_GET['id'] ?? 0);

		// Usuário-alvo
		$st = $pdo->prepare("SELECT * FROM users WHERE id = :id");
		$st->bindValue(':id', $targetId, \PDO::PARAM_INT);
		$st->execute();
		$user = $st->fetch();
		if (!$user) { http_response_code(404); exit('Usuário não encontrado.'); }

		// Códigos de permissão que vamos editar no modal
		$codes = [
			'is_admin',
			'users.manage',
			'drilling.analise_di',
			'drilling.tabela_getman',
			'drilling.tabela_boart',
			'agro.tabela_massey',
			'hr.colaboradores',
			'hr.organograma_proposta',
			'rh.composicao_remuneracao',
			'almoxarifado.manage',
		];

		// Carrega níveis atuais
		$levels = array_fill_keys($codes, 0);
		$in = implode(',', array_fill(0, count($codes), '?'));
		$stmt = $pdo->prepare("SELECT permission_code, level FROM user_permissions WHERE user_id = ? AND permission_code IN ($in)");
		$params = array_merge([$targetId], $codes);
		$stmt->execute($params);
		foreach ($stmt->fetchAll() as $row) {
			$levels[$row['permission_code']] = (int)$row['level'];
		}

		// GET → renderiza o modal (parcial) ou página
		if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
			$categorias       = Categoria::findAll([], 'nome');
			$almoxCatLevels   = AlmoxPermission::getForUser($targetId);
			$vars = ['user' => $user, 'levels' => $levels, 'categorias' => $categorias, 'almoxCatLevels' => $almoxCatLevels];
			if (isset($_GET['modal'])) view('permissions/_user_permissions.php', $vars);
			else render_page('permissions/_user_permissions.php', $vars);
			return;
		}

		// POST → salva
		check_csrf();

		// Lê os valores enviados pelo formulário (0/1/2), com limites
		$newIsAdmin      = (\Security\Permission::isAdmin() && isset($_POST['perm_is_admin']))
		                   ? (int)$_POST['perm_is_admin'] : (int)($levels['is_admin'] ?? 0);
		$newUsersManage  = isset($_POST['perm_users_manage'])            ? (int)$_POST['perm_users_manage']            : 0;
		$newDrillingDI   = isset($_POST['perm_drilling_analise_di'])     ? (int)$_POST['perm_drilling_analise_di']     : 0;
		$newTabelaGetman = isset($_POST['perm_drilling_tabela_getman'])  ? (int)$_POST['perm_drilling_tabela_getman']  : 0;
		$newTabelaBoart  = isset($_POST['perm_drilling_tabela_boart'])   ? (int)$_POST['perm_drilling_tabela_boart']   : 0;
		$newTabelaMassey = isset($_POST['perm_agro_tabela_massey'])      ? (int)$_POST['perm_agro_tabela_massey']      : 0;
		$newHrColabs     = isset($_POST['perm_hr_colaboradores'])           ? (int)$_POST['perm_hr_colaboradores']           : 0;
		$newOrgProposta  = isset($_POST['perm_hr_organograma_proposta'])    ? (int)$_POST['perm_hr_organograma_proposta']    : 0;
		$newRhComp       = isset($_POST['perm_rh_composicao_remuneracao'])  ? (int)$_POST['perm_rh_composicao_remuneracao']  : 0;
		$newAlmoxManage  = isset($_POST['perm_almoxarifado_manage'])        ? (int)$_POST['perm_almoxarifado_manage']        : 0;

		$toSave = [
			'is_admin'                  => max(0, min(1, $newIsAdmin)),
			'users.manage'              => max(0, min(2, $newUsersManage)),
			'drilling.analise_di'       => max(0, min(2, $newDrillingDI)),
			'drilling.tabela_getman'    => max(0, min(2, $newTabelaGetman)),
			'drilling.tabela_boart'     => max(0, min(2, $newTabelaBoart)),
			'agro.tabela_massey'        => max(0, min(2, $newTabelaMassey)),
			'hr.colaboradores'          => max(0, min(2, $newHrColabs)),
			'hr.organograma_proposta'   => max(0, min(1, $newOrgProposta)),
			'rh.composicao_remuneracao' => max(0, min(2, $newRhComp)),
			'almoxarifado.manage'       => max(0, min(2, $newAlmoxManage)),
		];

		foreach ($toSave as $code => $lvl) {
			$upd = $pdo->prepare("UPDATE dbo.user_permissions SET level = :lvl WHERE user_id = :uid AND permission_code = :code");
			$upd->execute([':lvl' => $lvl, ':uid' => $targetId, ':code' => $code]);

			if ($upd->rowCount() === 0) {
				$ins = $pdo->prepare("INSERT INTO dbo.user_permissions (user_id, permission_code, level) VALUES (:uid, :code, :lvl)");
				$ins->execute([':uid' => $targetId, ':code' => $code, ':lvl' => $lvl]);
			}

			// Atualiza cache de sessão (se o alvo for o usuário logado)
			if (!empty($_SESSION['user']['id']) && (int)$_SESSION['user']['id'] === $targetId) {
				$_SESSION['perm_levels'][$code] = $lvl;
			}
		}

		// Salva permissões de categoria do almoxarifado (0-3)
		$categorias = Categoria::findAll([], 'nome');
		$catLevels  = [];
		foreach ($categorias as $cat) {
			$postKey = 'perm_alm_cat_' . $cat->id;
			$catLevels[$cat->id] = isset($_POST[$postKey]) ? max(0, min(3, (int)$_POST[$postKey])) : 0;
		}
		AlmoxPermission::saveForUser($targetId, $catLevels);

		if (isset($_GET['ajax'])) {
			header('Content-Type: application/json');
			echo json_encode(['ok' => true, 'message' => 'Permissões atualizadas com sucesso.']);
			return;
		}
		redirect('users');
	}
}
?>