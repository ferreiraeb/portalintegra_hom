<?php
namespace Services;

class LdapService {
    /** ADS_UF_ACCOUNTDISABLE — conta desabilitada no AD. */
    private const UAC_ACCOUNTDISABLE = 2;

    private $conn;
    private $cfg;

    public function __construct(array $cfg) {
        $this->cfg = $cfg;
    }

    private function connectAndBindService() {
        $this->conn = ldap_connect($this->cfg['ldap_uri'], $this->cfg['ldap_port']);
        if (!$this->conn) {
            throw new \RuntimeException('Falha ao conectar no LDAP');
        }

        ldap_set_option($this->conn, LDAP_OPT_PROTOCOL_VERSION, 3);
        ldap_set_option($this->conn, LDAP_OPT_REFERRALS, 0);

        // ✅ Suprimir warnings de STARTTLS (evita enviar bytes antes de header())
        if (!empty($this->cfg['use_starttls'])) {
            if (!@ldap_start_tls($this->conn)) {
                // (Opcional) faça log em vez de echo/var_dump
                error_log('[LDAP] Falha ao iniciar STARTTLS');
                throw new \RuntimeException('Falha ao iniciar STARTTLS no LDAP');
            }
        }

        if (!@ldap_bind($this->conn, $this->cfg['bind_dn'], $this->cfg['bind_password'])) {
            throw new \RuntimeException('Bind LDAP (service account) falhou');
        }
    }

    /**
     * Contas de pessoa no AD, inclusive desativadas (férias/licença).
     * is_active reflete o bit ACCOUNTDISABLE do userAccountControl.
     */
    public function searchActiveUsers(): array {
        if (empty($this->cfg['enabled'])) return [];
        $this->connectAndBindService();

        $filter = $this->cfg['user_filter'];
        $attrs  = $this->cfg['attributes'];

        $sr = @ldap_search($this->conn, $this->cfg['base_dn'], $filter, $attrs);
        if (!$sr) {
            $err = ldap_error($this->conn);
            @ldap_unbind($this->conn);
            throw new \RuntimeException('Busca LDAP falhou: ' . $err);
        }

        $entries = ldap_get_entries($this->conn, $sr);

        $users = [];
        for ($i = 0; $i < ($entries['count'] ?? 0); $i++) {
            $e   = $entries[$i];
            $uac = isset($e['useraccountcontrol'][0]) ? (int)$e['useraccountcontrol'][0] : null;
            $users[] = [
                'dn'                 => $e['distinguishedname'][0] ?? null,
                'displayName'        => $e['displayname'][0] ?? null,
                'givenName'          => $e['givenname'][0] ?? null,
                'sn'                 => $e['sn'][0] ?? null,
                'mail'               => $e['mail'][0] ?? null,
                'department'         => $e['department'][0] ?? null,
                'title'              => $e['title'][0] ?? null,
                'company'            => $e['company'][0] ?? null,
                'manager'            => $e['manager'][0] ?? null,
                'office'             => $e['physicaldeliveryofficename'][0] ?? null,
                'phone'              => $e['telephonenumber'][0] ?? null,
                'sAMAccountName'     => $e['samaccountname'][0] ?? null,
                'upn'                => $e['userprincipalname'][0] ?? null,
                'employeeNumber'     => $e['employeenumber'][0] ?? null,
                'userAccountControl' => $uac,
                'lockoutTime'        => isset($e['lockouttime'][0]) ? (int)$e['lockouttime'][0] : null,
                'is_active'          => self::isAccountEnabled($uac) ? 1 : 0,
            ];
        }
        @ldap_unbind($this->conn);
        return $users;
    }

    public static function isAccountEnabled(?int $uac): bool
    {
        if ($uac === null) {
            return true;
        }
        return ($uac & self::UAC_ACCOUNTDISABLE) === 0;
    }

    /**
     * Busca no AD um usuário pelo e-mail (mail / UPN / proxyAddresses) ou sAMAccountName.
     * Retorna sAMAccountName, UPN e displayName; null se não encontrado.
     */
    public function findUserByMail(string $email): ?array {
        return $this->findAccount($email);
    }

    public function findAccount(string $identifier): ?array {
        if (empty($this->cfg['enabled'])) return null;
        try {
            $this->connectAndBindService();
        } catch (\RuntimeException $e) {
            error_log('[LDAP] findAccount – bind falhou: ' . $e->getMessage());
            return null;
        }

        $norm  = strtolower(trim($identifier));
        $local = strpos($norm, '@') !== false ? explode('@', $norm, 2)[0] : $norm;
        $mail  = ldap_escape($norm, '', LDAP_ESCAPE_FILTER);
        $sam   = ldap_escape($local, '', LDAP_ESCAPE_FILTER);
        $attrs = ['sAMAccountName', 'userPrincipalName', 'displayName', 'mail'];

        $filters = [];
        if (strpos($norm, '@') !== false) {
            $filters[] = '(&(objectCategory=person)(objectClass=user)(|(mail=' . $mail . ')(userPrincipalName=' . $mail . ')(proxyAddresses=SMTP:' . $mail . ')(proxyAddresses=smtp:' . $mail . ')))';
        }
        $filters[] = '(&(objectCategory=person)(objectClass=user)(sAMAccountName=' . $sam . '))';

        $found = null;
        foreach ($filters as $filter) {
            $sr = @ldap_search($this->conn, $this->cfg['base_dn'], $filter, $attrs);
            if (!$sr) {
                continue;
            }
            $entries = ldap_get_entries($this->conn, $sr);
            if (($entries['count'] ?? 0) > 0) {
                $e = $entries[0];
                $found = [
                    'sAMAccountName' => $e['samaccountname'][0] ?? null,
                    'upn'            => $e['userprincipalname'][0] ?? null,
                    'displayName'    => $e['displayname'][0] ?? null,
                    'mail'           => $e['mail'][0] ?? null,
                ];
                break;
            }
        }

        @ldap_unbind($this->conn);
        return $found;
    }

    // Autentica tentando bind com credenciais do usuário
    public function authenticateUserPassword(string $username, string $password): bool {
        if (empty($this->cfg['enabled'])) return false;
        if ($username === '' || $password === '') return false;

        $userDn = $username;
        if (strpos($username, '@') === false && !empty($this->cfg['user_upn_suffix'])) {
            $userDn = $username . $this->cfg['user_upn_suffix']; // ex: user@valence.ad
        }

        $conn = ldap_connect($this->cfg['ldap_uri'], $this->cfg['ldap_port']);
        if (!$conn) return false;

        ldap_set_option($conn, LDAP_OPT_PROTOCOL_VERSION, 3);
        ldap_set_option($conn, LDAP_OPT_REFERRALS, 0);

        // ✅ também suprimir aqui (você já fazia, mantive)
        if (!empty($this->cfg['use_starttls'])) {
            if (!@ldap_start_tls($conn)) {
                @ldap_unbind($conn);
                return false;
            }
        }

        $ok = @ldap_bind($conn, $userDn, $password);
        @ldap_unbind($conn);
        return $ok;
    }
}

